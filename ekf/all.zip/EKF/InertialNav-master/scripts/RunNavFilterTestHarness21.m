clear all;
close all;
LoadNavFilterTestData
sim('NavFilterTestHarness21')
PlotNavFilterData21