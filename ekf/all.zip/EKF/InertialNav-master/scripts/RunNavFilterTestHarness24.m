clear all;
close all;
LoadNavFilterTestData;
sim('NavFilterTestHarness24')
PlotNavFilterData24